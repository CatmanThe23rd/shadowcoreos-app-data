# ShadowCoreOS App Data
Central JSON database for ShadowCoreOS app metadata, categories, and workflow logic.

Public repo maintained by: **CatmanThe23rd**

Your apps can auto-update by pulling raw JSON files from:

https://raw.githubusercontent.com/CatmanThe23rd/shadowcoreos-app-data/main/
