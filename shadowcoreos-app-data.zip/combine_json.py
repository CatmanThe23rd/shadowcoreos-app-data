# placeholder script
print('merge')